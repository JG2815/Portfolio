local training2 = {}
local projectiles = {}

local winTime = 15  -- Time required to win in seconds
local timeSurvived = 0  -- Time the player has survived
local hasWon = false  -- Flag to check if the player has won

local lanes = {}
local currentLane

local creature = {
    x = 0,
    y = 0, -- Initialize default y position here
    speed = 100,
    sprites = {},
    currentFrame = 1,
    scale = multiplier
}

local laneThickness = 25 -- Fixed lane thickness

function training2.reset()
    projectiles = {}
    currentLane = 2  -- Set it directly here for consistency
    creature.x = 0
    creature.y = lanes[currentLane] - (creature.sprites[creature.currentFrame]:getHeight() * creature.scale / 2) - laneThickness / 2


    timeSurvived = 0
    hasWon = false
    keyPressed = false
end

function training2.load(multiplier, windowW, windowH)
    love.graphics.setDefaultFilter("nearest", "nearest", 0)

    if not windowW or windowW <= 0 then
        windowW = 800 -- Fallback to a default width
    end
    
    timeSurvived = 0
    hasWon = false
    

    creature.x = (windowW / 20) * multiplier
    creature.scale = multiplier * 0.85

    local success, sprite1 = pcall(love.graphics.newImage, "Sprites/Menu/Slime_003.png")
    local success2, sprite2 = pcall(love.graphics.newImage, "Sprites/Menu/Slime_004.png")

    if success and sprite1 then
        creature.sprites[1] = sprite1
    end

    if success2 and sprite2 then
        creature.sprites[2] = sprite2
    end

    local laneHeight = (windowH - laneThickness) / 3
    lanes = {
        laneHeight * 0.5,
        laneHeight * 1.5,
        laneHeight * 2.5
    }

    currentLane = 2
    creature.y = lanes[currentLane] - (creature.sprites[creature.currentFrame]:getHeight() * creature.scale / 2) - laneThickness / 2


    training2.reset()
end

local keyPressed = false

function training2.update(dt, windowW, windowH)
    windowW = windowW or love.graphics.getWidth()
    windowH = windowH or love.graphics.getHeight()

    if not windowW or windowW <= 0 then
        windowW = 800
    end

    if not hasWon then
        timeSurvived = timeSurvived + dt

        if timeSurvived >= winTime then
            local expGained = 10
            Exp = Exp + expGained
            hasWon = true
            love.timer.sleep(0.5)
            changeState("menu")
            training2.reset()
            return
        end
    end

    if not windowH or windowH <= 0 then
        windowH = 600
    end

    creature.currentFrame = creature.currentFrame + 1
    if creature.currentFrame > #creature.sprites then
        creature.currentFrame = 1
    end
    
    if not keyPressed then
        if love.keyboard.isDown("up") then
            currentLane = math.max(1, currentLane - 1)
            keyPressed = true
        elseif love.keyboard.isDown("down") then
            currentLane = math.min(#lanes, currentLane + 1)
            keyPressed = true
        end
    end

    if not love.keyboard.isDown("up") and not love.keyboard.isDown("down") then
        keyPressed = false
    end

    creature.y = lanes[currentLane] - (creature.sprites[creature.currentFrame]:getHeight() * creature.scale / 2) - laneThickness / 2

    if math.random() < 0.008 then
        local lane = math.random(1, 3)
        local newProjectile = {
            x = windowW, 
            y = lanes[lane] - (laneThickness / 4),
            lane = lane, 
            speed = 70 * multiplier
        }

        if newProjectile.x and newProjectile.y and newProjectile.speed then
            table.insert(projectiles, newProjectile)
        end
    end

    for i = #projectiles, 1, -1 do
        local proj = projectiles[i]
        if proj.x then
            proj.x = proj.x - proj.speed * dt
        end

        if proj.x and proj.x < 0 then
            table.remove(projectiles, i)
        end
    end

    for _, proj in ipairs(projectiles) do
        if proj.lane == currentLane and proj.x < creature.x + creature.sprites[creature.currentFrame]:getWidth() * creature.scale then
            changeState("menu")
            training2.reset()
            return
        end
    end
end

function training2.draw(windowW, windowH)
    love.graphics.setColor(1, 1, 0)

    for i, laneY in ipairs(lanes) do
        if laneY then
            love.graphics.rectangle("fill", 0, laneY - (laneThickness / 2), windowW, laneThickness)
        end
    end

    love.graphics.setColor(1, 1, 1)

    if #creature.sprites > 0 and creature.sprites[creature.currentFrame] then
        love.graphics.draw(creature.sprites[creature.currentFrame], creature.x, creature.y, 0, creature.scale, creature.scale)
    end

    for _, proj in ipairs(projectiles) do
        if proj.x and proj.y then
            love.graphics.rectangle("fill", proj.x, proj.y - (laneThickness / 4), 30, 25)
        end
    end
end

return training2
