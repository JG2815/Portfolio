local creature = {}

function creature.init(multiplier, windowW, windowH)
    creature.multiplier = multiplier
    creature.windowW = windowW
    creature.windowH = windowH
    creature.x = 75 * multiplier
    creature.y = 75 * multiplier
    creature.speed = 50 * multiplier -- Speed in pixels per second
    creature.direction = -1 -- 1 for right, -1 for left
    creature.sprites = {}
    creature.currentFrame = 1
    creature.animationTimer = 0
    creature.animationInterval = 0.5 -- Time in seconds between frames
    creature.isMoving = true -- Indicates if the creature is moving
    creature.stopDuration = 0 -- Time to stop in seconds
    creature.stopTimer = 0 -- Timer for how long the creature has stopped
    creature.kaijuStats = {
        Health = 150,
        Attack = 40,
        Defense = 5,
        Radiant = 100,
        Speed = 35,
    }
end

function creature.load()
    creature.sprites[1] = love.graphics.newImage("Sprites/Menu/Slime_001.png") -- Load first frame
    creature.sprites[2] = love.graphics.newImage("Sprites/Menu/Slime_002.png") -- Load second frame
    creature.sprites[3] = love.graphics.newImage("Sprites/Menu/Slime_003.png") -- Load third frame
    creature.sprites[4] = love.graphics.newImage("Sprites/Menu/Slime_004.png") -- Load fourth frame
end

function creature.update(dt)
    if creature.isMoving then
        -- Update position
        creature.x = creature.x + creature.speed * creature.direction * dt

        -- Store the previous direction
        local previousDirection = creature.direction

        -- Change direction randomly
        if math.random() < 0.0001 then
            creature.direction = -creature.direction
        end

        -- Ensure creature stays within screen bounds
        if creature.x < 0 then
            creature.x = 0
            creature.direction = 1
        elseif creature.x > (creature.windowW * creature.multiplier) - creature.sprites[creature.currentFrame]:getWidth() then
            creature.x = (creature.windowW * creature.multiplier) - creature.sprites[creature.currentFrame]:getWidth()
            creature.direction = -1
        end

        -- Check for direction change
        if previousDirection ~= creature.direction then
            creature.currentFrame = creature.direction == 1 and 3 or 1 -- Set to initial frame based on direction
            creature.animationTimer = 0
        end

        -- Update animation
        creature.animationTimer = creature.animationTimer + dt
        if creature.animationTimer >= creature.animationInterval then
            creature.animationTimer = 0
            creature.currentFrame = creature.currentFrame + 1
            if creature.direction == 1 then
                if creature.currentFrame > 4 then creature.currentFrame = 3 end -- Loop between 3 and 4 for moving right
            else
                if creature.currentFrame > 2 then creature.currentFrame = 1 end -- Loop between 1 and 2 for moving left
            end
        end

        -- Randomly decide to stop
        if math.random() < 0.001 then
            creature.isMoving = false
            creature.stopDuration = math.random(1, 3) -- Stop for 1 to 3 seconds
            creature.stopTimer = 0
            creature.currentFrame = creature.direction == 1 and 3 or 1 -- Set to idle frame based on direction
        end
    else
        -- Update stop timer
        creature.stopTimer = creature.stopTimer + dt
        if creature.stopTimer >= creature.stopDuration then
            creature.isMoving = true
            creature.stopTimer = 0
            creature.currentFrame = creature.direction == 1 and 4 or 2 -- Set to moving frame based on direction
        end
    end
end

function creature.draw()
    if #creature.sprites > 0 then
        local sprite = creature.sprites[creature.currentFrame]
        love.graphics.draw(sprite, creature.x / creature.multiplier, creature.y / creature.multiplier, 0, creature.multiplier, creature.multiplier, sprite:getWidth() / 2, sprite:getHeight() / 2)
    end
end

function creature.drawKaijuStats()
    local statLabels = {"HP", "ATK", "DEF", "RAD", "SPD"}
    local statValues = {creature.kaijuStats.Health, creature.kaijuStats.Attack, creature.kaijuStats.Defense, creature.kaijuStats.Radiant, creature.kaijuStats.Speed}
    
    -- Load the background image
    local backgroundImage = love.graphics.newImage("Sprites/Menu/StatBackground.png")

    -- Set the original size of the rectangles before scaling
    local originalSize = 32
    local backgroundWidth = originalSize * creature.multiplier / creature.multiplier
    local backgroundHeight = originalSize * creature.multiplier / creature.multiplier

    -- Set the number of background rectangles to 5
    local numRects = 5
    
    -- Calculate the total width of all rectangles plus the spacing in between
    local totalRectanglesWidth = numRects * backgroundWidth
    
    -- Calculate the total available space after accounting for the rectangles
    local availableSpace = creature.windowW - totalRectanglesWidth
    
    -- Calculate the margin (spacing) between each rectangle
    local spacing = availableSpace / (numRects + 1)  -- Adjusted to match the top spacing

    -- Calculate the y position for the rectangles at the bottom of the screen
    local y = creature.windowH - backgroundHeight  -- Positioned at the bottom of the screen

    -- Draw the background images with spacing between them
    for i = 0, numRects - 1 do
        local x = (i + 1) * spacing + i * backgroundWidth  -- Adjusted to match the top spacing
        love.graphics.draw(backgroundImage, x, y, 0, backgroundWidth / backgroundImage:getWidth(), backgroundHeight / backgroundImage:getHeight())
    end

    -- Reset color for text
    love.graphics.setColor(0, 0, 0, 1)

    -- Draw each stat label and value
    local textX = spacing  -- Adjusted to match the top spacing
    local labelY = y - 2  -- Position the labels higher
    local valueY = y + 10  -- Position the values lower
    local offset = 3  -- Offset to move the labels and values to the right
    for i = 1, #statLabels do
        local label = statLabels[i]
        local value = statValues[i]
        love.graphics.print(label, textX + offset, labelY)
        love.graphics.print(value, textX + offset, valueY)
        textX = textX + backgroundWidth + spacing
    end
end





return creature
