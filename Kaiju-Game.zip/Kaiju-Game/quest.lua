local quest = {}

local questsList = {"Quest 1", "Quest 2", "Quest 3"} -- Quest names
local questComplete = {false, false, false} -- Tracks if each quest is completed
local selectedQuest = 1 -- Currently selected quest in the menu
local currentQuest = nil -- The quest the player is currently playing
local battleInProgress = false -- Flag to check if a battle is happening
local selectedCommand = 1 -- Command selection during battle

-- Function to load quests from a file
function quest.loadQuests(filename)
    local quests = {}
    local currentQuest = nil

    for line in love.filesystem.lines(filename) do
        print("Line:", line) -- Debug: Print each line
        line = line:match("^%s*(.-)%s*$") -- Trim whitespace

        if line:find("^Quest %d+:$") then
            currentQuest = tonumber(line:match("Quest (%d+)"))
            quests[currentQuest] = {}
        elseif line:find("Stage") and currentQuest then
            local stage, data = line:match("Stage (%d+): (.+)")
            stage = tonumber(stage)

            local kaiju = {
                id = data:match("Kaiju%.No%.(%d+)"),
                lvl = tonumber(data:match("LVL%s*=%s*(%d+)")) or 1,
                hp = tonumber(data:match("HP%s*=%s*(%d+)")),
                atk = tonumber(data:match("ATK%s*=%s*(%d+)")),
                def = tonumber(data:match("DEF%s*=%s*(%d+)")),
                rad = tonumber(data:match("RAD%s*=%s*(%d+)")),
                spd = tonumber(data:match("SPD%s*=%s*(%d+)")),
                exp = tonumber(data:match("EXP%s*=%s*(%d+)"))
            }

            print("Parsed Kaiju:", kaiju) -- Debug: Print parsed data
            quests[currentQuest][stage] = kaiju
        end
    end

    return quests
end


function quest.load(multiplier, windowW, windowH)
    quest.windowW = windowW
    quest.windowH = windowH
    print("Quest selection system initialized")

    -- Load quests from quest.txt
    quest.quests = quest.loadQuests("questinfo.txt")

    -- Debug: Print loaded quests
    for questNumber, stages in pairs(quest.quests) do
        print("Quest:", questNumber)
        for stageNumber, kaiju in pairs(stages) do
            print("  Stage:", stageNumber)
            print("    Kaiju ID:", kaiju.id, "Level:", kaiju.lvl)
            print("    HP:", kaiju.hp, "ATK:", kaiju.atk, "DEF:", kaiju.def)
            print("    RAD:", kaiju.rad, "SPD:", kaiju.spd, "EXP:", kaiju.exp)
        end
    end
end

function quest.update(dt)
    -- Update logic, if any (not needed for now)
end

function quest.draw()
    if not battleInProgress then
        -- Draw the quest selection screen
        love.graphics.print("Choose a Quest:", 10, 10)

        for i, questName in ipairs(questsList) do
            local y = 40 + (i - 1) * 30 -- Vertical spacing for quest options

            if i == selectedQuest then
                love.graphics.setColor(1, 0, 0) -- Highlight selected quest in red
            else
                love.graphics.setColor(1, 1, 1) -- White for unselected
            end

            -- Gray out locked quests
            if questComplete[i] or i == 1 or questComplete[i - 1] then
                love.graphics.print(questName, 10, y)
            else
                love.graphics.setColor(0.5, 0.5, 0.5) -- Dim for locked quests
                love.graphics.print(questName .. " (Locked)", 10, y)
            end
        end
    else
        -- Draw the battle screen
        love.graphics.print("Current Quest: " .. questsList[currentQuest], 10, 10)

        local commandY = quest.windowH - 40 -- Y position for commands
        for i, command in ipairs(commands) do
            local x = 10 + (i - 1) * 100 -- Horizontal spacing for commands
            if i == selectedCommand then
                love.graphics.setColor(1, 0, 0) -- Highlight selected command in red
            else
                love.graphics.setColor(1, 1, 1) -- White for unselected
            end

            love.graphics.print(command, x, commandY)
        end
    end
end

function quest.keypressed(key)
    if not battleInProgress then
        -- Navigate the quest selection menu
        if key == "down" then
            selectedQuest = math.min(selectedQuest + 1, #questsList)
        elseif key == "up" then
            selectedQuest = math.max(selectedQuest - 1, 1)
        elseif key == "return" then
            -- Check if the quest is unlocked
            if questComplete[selectedQuest] or selectedQuest == 1 or questComplete[selectedQuest - 1] then
                quest.startBattle(selectedQuest)
            else
                print("This quest is locked!")
            end
        elseif key == "escape" then
            love.event.quit() -- Exit the game
        end
    elseif battleInProgress then
        -- Handle commands during the battle
        if key == "right" then
            selectedCommand = math.min(selectedCommand + 1, #commands)
        elseif key == "left" then
            selectedCommand = math.max(selectedCommand - 1, 1)
        elseif key == "return" then
            quest.executeCommand(commands[selectedCommand])
        end
    end
end

function quest.startBattle(questIndex)
    currentQuest = questIndex
    battleInProgress = true

    -- Retrieve Kaiju data for the current quest
    local kaiju = quest.quests[1][questIndex] -- Example: Quest 1, current quest
    print("Starting battle against Kaiju ID:", kaiju.id)
    print("Kaiju Stats: HP=", kaiju.hp, "ATK=", kaiju.atk, "DEF=", kaiju.def)
end

function quest.executeCommand(command)
    -- Execute the selected command during battle
    if command == "Attack" then
        print("You attack the enemy in " .. questsList[currentQuest])
        quest.completeQuest()
    elseif command == "Defend" then
        print("You defend against an attack in " .. questsList[currentQuest])
        -- Add custom defend logic here
    elseif command == "Item" then
        print("You use an item in " .. questsList[currentQuest])
        -- Add logic for using an item here
    end
end

function quest.completeQuest()
    -- Mark the current quest as complete
    questComplete[currentQuest] = true
    print(questsList[currentQuest] .. " completed!")
    battleInProgress = false -- End the battle and return to the menu
end

function quest.allQuestsCompleted()
    for _, complete in ipairs(questComplete) do
        if not complete then
            return false
        end
    end
    return true
end

return quest
