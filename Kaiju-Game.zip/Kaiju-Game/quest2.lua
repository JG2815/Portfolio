local quest2 = {}

-- Button definitions with original positions and dimensions
local attackButton = { 
    baseX = 0, 
    baseY = 110, 
    baseWidth = 45, 
    baseHeight = 40, 
    text = "Attack", 
    hover = false,
    x = 0,
    y = 110,
    width = 45,
    height = 40
}

local defendButton = { 
    baseX = 115, 
    baseY = 110, 
    baseWidth = 45, 
    baseHeight = 40, 
    text = "Defend", 
    hover = false,
    x = 115,
    y = 110,
    width = 45,
    height = 40
}

local itemButton = { 
    baseX = 58, 
    baseY = 110, 
    baseWidth = 45, 
    baseHeight = 40, 
    text = "Item", 
    hover = false,
    x = 58,
    y = 110,
    width = 45,
    height = 40
}

local playerHP = nil
local enemyHP = nil
local currentStage = 1
local totalStages = 0 
local enemyData = nil
local isDefending = false
local questData = nil
local items = require "items"
local activeBoost = nil
local activeBoostTurns = 0
local inCombat = true

local creature = require "creature"

playerItems = {}  -- Declare as global to hold player's items

function quest2.reset()
    currentStage = 1
    playerHP = creature.kaijuStats.Health  -- Reset player HP to max
    activeBoost = nil  -- Clear any active boosts
    boostTurnsLeft = 0  -- Reset boost turns
    enemyData = nil  -- Clear enemy data
    print("Quest reset to Stage 1. Player HP restored.")
    quest2.loadStageData(currentStage)  -- Load the data for the first stage
end

function quest2.applyItemEffect(itemId)
    if activeBoost and items.list[itemId].effect ~= "boostHealth" then
        print("An item boost is already active: " .. activeBoost.name .. " (" .. activeBoostTurns .. " turns left)")
        return false
    end

    local item = items.list[itemId]
    if not item then return false end

    if items.removeFromInventory(itemId) then
        if item.effect == "boostHealth" then
            local oldHP = playerHP
            playerHP = playerHP + item.amount
            print(string.format("Health: %d -> %d (restored by %d)", oldHP, playerHP, item.amount))
            return true
        elseif item.effect == "boostAttack" then
            local oldAttack = creature.kaijuStats.Attack
            creature.kaijuStats.Attack = oldAttack + item.amount
            activeBoost = item
            activeBoostTurns = item.duration
            print(string.format("Attack: %d -> %d (boosted by %d for %d turns)", 
                oldAttack, creature.kaijuStats.Attack, item.amount, activeBoostTurns))
            return true
        elseif item.effect == "boostDefense" then
            local oldDefense = creature.kaijuStats.Defense
            creature.kaijuStats.Defense = oldDefense + item.amount
            activeBoost = item
            activeBoostTurns = item.duration
            print(string.format("Defense: %d -> %d (boosted by %d for %d turns)", 
                oldDefense, creature.kaijuStats.Defense, item.amount, activeBoostTurns))
            return true
        end
    end
    return false
end

function quest2.nextStage()
    if currentStage < totalStages then
        currentStage = currentStage + 1
        quest2.loadStageData(currentStage)
        print(string.format("Advanced to Stage %d/%d", currentStage, totalStages))
        
        -- Award an item when the player wins a stage
        local randomItem = items.getRandomItem()
        if randomItem and randomItem.name then
            table.insert(playerItems, randomItem)  -- Add the item to the player's inventory
            print("You received an item:", randomItem.name)
        end
    else
        print("No more stages! Quest complete!")
        -- Award an item for the last stage
        local randomItem = items.getRandomItem()
        if randomItem and randomItem.name then
            table.insert(playerItems, randomItem)  -- Add the item to the player's inventory
            print("You received an item:", randomItem.name)
        end
        
        quest2.reset()  -- Reset the quest when complete
        changeState("menu")  -- Change to the menu or any other state
    end
end

function quest2.loadStageData(stageIndex)
    enemyData = questData[stageIndex]
    enemyHP = math.floor(enemyData.hp)

    print("Loaded enemy data for Stage:", stageIndex)
    for key, value in pairs(enemyData) do
        print(key, value)
    end
end

function quest2.defendCommand()
    print("Player chose to defend!")
    isDefending = true

    -- Handle boost duration
    if activeBoost then
        activeBoostTurns = activeBoostTurns - 1
        if activeBoostTurns <= 0 then
            if activeBoost.effect == "boostAttack" then
                creature.kaijuStats.Attack = creature.kaijuStats.Attack - activeBoost.amount
                print("Attack boost expired!")
            elseif activeBoost.effect == "boostDefense" then
                creature.kaijuStats.Defense = creature.kaijuStats.Defense - activeBoost.amount
                print("Defense boost expired!")
            end
            activeBoost = nil
        end
    end

    quest2.enemyAttack()
end

function quest2.enemyAttack()
    -- Calculate enemy damage
    local enemyAttackStat = enemyData.atk
    local minDamage = math.floor(enemyAttackStat * 0.8)
    local maxDamage = math.floor(enemyAttackStat * 1.1)
    local damage = math.random(minDamage, maxDamage)
    local playerDefenseStat = creature.kaijuStats.Defense
    -- Critical hit logic (10% chance)
    if math.random(100) <= 10 then
        damage = math.floor(damage * 1.3) -- Critical hit multiplier
        print("Enemy critical hit!")
    end

    if isDefending then
        damage = math.max(damage - playerDefenseStat, 0)
        print(string.format("Player defended! Damage reduced to %d.", damage))
        isDefending = false -- Reset defense state after reducing damage
    end

    -- Apply damage to player's HP
    playerHP = math.max(playerHP - damage, 0)

    -- Debug output
    print(string.format("Enemy dealt %d damage. Player HP: %d", damage, playerHP))

    -- Check if player is defeated
    if playerHP <= 0 then
        print("Player is defeated! Game over or retry.")
        quest2.reset()  -- Reset the quest when the player is defeated
        changeState("menu")  -- Change to the menu or any other state
    end
end

function quest2.attackCommand()
    -- Calculate damage with current stats
    local kaijuAttackStat = creature.kaijuStats.Attack
    local baseDamage = math.floor(math.random(kaijuAttackStat * 0.8, kaijuAttackStat * 1.1))

    -- Critical hit logic
    local criticalChance = 15 
    local isCritical = math.random(100) <= criticalChance
    if isCritical then
        baseDamage = math.floor(baseDamage * math.random(1.2, 1.5))
        print("Critical Hit!")
    end

    -- Apply damage
    enemyHP = enemyHP - baseDamage
    print(string.format("Player dealt %d damage. Enemy HP: %d", baseDamage, enemyHP))

    -- Handle boost duration
    if activeBoost then
        activeBoostTurns = activeBoostTurns - 1
        if activeBoostTurns <= 0 then
            if activeBoost.effect == "boostAttack" then
                creature.kaijuStats.Attack = creature.kaijuStats.Attack - activeBoost.amount
                print("Attack boost expired!")
            elseif activeBoost.effect == "boostDefense" then
                creature.kaijuStats.Defense = creature.kaijuStats.Defense - activeBoost.amount
                print("Defense boost expired!")
            end
            activeBoost = nil
        end
    end

    if enemyHP <= 0 then
        local expGained = enemyData.exp 
        Exp = Exp + expGained
        quest2.nextStage()
    else
        quest2.enemyAttack()
    end
end

function quest2.itemCommand()
    print("Item button clicked!")
    previousState = currentState
    changeState("foodScreen")
end

function quest2.useItem(item)
    if activeBoost then
        print("An item boost is already active. Please use it before applying another.")
        return
    end

    if item.effect == "boostHealth" then
        playerHP = math.min(playerHP + item.amount, creature.kaijuStats.Health)
        print("Health boosted by", item.amount)
    elseif item.effect == "boostAttack" then
        creature.kaijuStats.Attack = creature.kaijuStats.Attack + item.amount
        print("Attack boosted by", item.amount)
    elseif item.effect == "boostDefense" then
        creature.kaijuStats.Defense = creature.kaijuStats.Defense + item.amount
        print("Defense boosted by", item.amount)
    end

    activeBoost = item
    activeBoostTurns = item.duration  -- Set the duration for the active boost
end

function quest2.returnFromItem()
    changeState("quest2")
end

function quest2.load(multiplier, windowW, windowH, questDataInput)
    print("Quest 2 loaded with multiplier:", multiplier)

    questData = questDataInput
    totalStages = #questData
    print("Total stages in this quest:", totalStages)

    playerHP = math.floor(creature.kaijuStats.Health)
    quest2.loadStageData(currentStage)

    attackButton.width = attackButton.baseWidth
    attackButton.height = attackButton.baseHeight
    attackButton.x = attackButton.baseX
    attackButton.y = attackButton.baseY

    defendButton.width = defendButton.baseWidth
    defendButton.height = defendButton.baseHeight
    defendButton.x = defendButton.baseX
    defendButton.y = defendButton.baseY

    itemButton.width = itemButton.baseWidth
    itemButton.height = itemButton.baseHeight
    itemButton.x = itemButton.baseX
    itemButton.y = itemButton.baseY

    print("Player HP:", playerHP)
    print("Enemy HP:", enemyHP)
end

function quest2.draw()
    -- Draw buttons
    if attackButton.hover then
        love.graphics.setColor(1, 0, 0)
    else
        love.graphics.setColor(1, 1, 1)
    end
    love.graphics.rectangle("fill", attackButton.x, attackButton.y, attackButton.width, attackButton.height)
    love.graphics.setColor(0, 0, 0)
    love.graphics.print(attackButton.text, attackButton.x + 5, attackButton.y + 5)

    if defendButton.hover then
        love.graphics.setColor(1, 0, 0)
    else
        love.graphics.setColor(1, 1, 1)
    end
    love.graphics.rectangle("fill", defendButton.x, defendButton.y, defendButton.width, defendButton.height)
    love.graphics.setColor(0, 0, 0)
    love.graphics.print(defendButton.text, defendButton.x + 5, defendButton.y + 5)

    if itemButton.hover then
        love.graphics.setColor(1, 0, 0)
    else
        love.graphics.setColor(1, 1, 1)
    end
    love.graphics.rectangle("fill", itemButton.x, itemButton.y, itemButton.width, itemButton.height)
    love.graphics.setColor(0, 0, 0)
    love.graphics.print(itemButton.text, itemButton.x + 5, itemButton.y + 5)

    -- Draw HP and stage info
    love.graphics.setColor(1, 1, 1)
    local displayPlayerHP = math.max(playerHP, 0)
    local displayEnemyHP = math.max(enemyHP, 0)
    love.graphics.print("HP:" .. displayPlayerHP, 60, 95)
    love.graphics.print("HP:" .. displayEnemyHP, 120, 0)
    
    -- Draw Attack and Defense stats
    love.graphics.print("ATK:" .. creature.kaijuStats.Attack, 60, 80)
    love.graphics.print("DEF:" .. creature.kaijuStats.Defense, 120, 80)

    -- Draw stage info
    local stageText = string.format("Stage %d/%d", currentStage, totalStages)
    love.graphics.print(stageText, 2, 0)

    -- Draw active boost info
    if activeBoost and activeBoostTurns > 0 then
        love.graphics.setColor(1, 1, 1)
        local boostText = string.format("%s: %d turns", 
            activeBoost.description, activeBoostTurns)
        love.graphics.print(boostText, 2, 20)
    end
end

function quest2.update(dt)
    if not multiplier then multiplier = 1 end
    
    local mouseX, mouseY = love.mouse.getPosition()
    if not mouseX or not mouseY then return end
    
    mouseX = mouseX / multiplier
    mouseY = mouseY / multiplier

    -- Safe hover checks
    attackButton.hover = false
    defendButton.hover = false
    itemButton.hover = false

    if mouseX and mouseY then
        -- Attack button hover
        if attackButton.x and attackButton.width then
            attackButton.hover = mouseX >= attackButton.x and 
                                mouseX <= (attackButton.x + attackButton.width) and
                                mouseY >= attackButton.y and 
                                mouseY <= (attackButton.y + attackButton.height)
        end

        -- Defend button hover
        if defendButton.x and defendButton.width then
            defendButton.hover = mouseX >= defendButton.x and 
                                mouseX <= (defendButton.x + defendButton.width) and
                                mouseY >= defendButton.y and 
                                mouseY <= (defendButton.y + defendButton.height)
        end

        -- Item button hover
        if itemButton.x and itemButton.width then
            itemButton.hover = mouseX >= itemButton.x and 
                              mouseX <= (itemButton.x + itemButton.width) and
                              mouseY >= itemButton.y and 
                              mouseY <= (itemButton.y + itemButton.height)
        end
    end
end

function quest2.mousepressed(x, y, button, istouch, presses)
    if button == 1 then
        if attackButton.hover then
            print("Attack Button Clicked")
            quest2.attackCommand()
        elseif defendButton.hover then
            quest2.defendCommand()
        elseif itemButton.hover then
            quest2.itemCommand()
        end
    end
end

return quest2
