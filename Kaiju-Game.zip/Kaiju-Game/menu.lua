menuTable = {}
selectedIndex = 1

function menuResources()
    menuTable[1] = love.graphics.newImage("Sprites/Menu/MenuData.png")
    menuTable[2] = love.graphics.newImage("Sprites/Menu/MenuFood.png")
    menuTable[3] = love.graphics.newImage("Sprites/Menu/MenuTrain.png")
    menuTable[4] = love.graphics.newImage("Sprites/Menu/MenuQuest.png")
    menuTable[5] = love.graphics.newImage("Sprites/Menu/MenuStatsTop.png")
end

function menuControls()
    local mouseX, mouseY = love.mouse.getPosition()
    mouseX = mouseX / multiplier
    mouseY = mouseY / multiplier

    for i = 1, #menuTable - 1 do
        local menuX = (i - 1) * 32
        local menuY = 0
        local menuWidth = menuTable[i]:getWidth()
        local menuHeight = menuTable[i]:getHeight()
        if mouseX >= menuX and mouseX <= menuX + menuWidth and mouseY >= menuY and mouseY <= menuY + menuHeight then
            if selectedIndex ~= i then
                love.audio.stop(se2)
                love.audio.play(se2)
            end
            selectedIndex = i
            if love.mouse.isDown(1) then -- Left mouse button is pressed
                love.audio.stop(se3)
                love.audio.play(se3)
                if i == 1 then
                    changeState("dataScreen")
                elseif i == 2 then
                    previousState = "menu"  -- Track that we came from menu
                    changeState("foodScreen") -- Allow using items on the food screen
                elseif i == 3 then
                    changeState("trainScreen")
                elseif i == 4 then
                    changeState("questScreen") -- Allow using items on the quest screen
                end
            end
        end
    end
end

function menuDraw()
    for i, menuImage in ipairs(menuTable) do
        if i == selectedIndex then
            love.graphics.setColor(1, 0, 0) -- Highlight selected item
        else
            love.graphics.setColor(1, 1, 1) -- Normal color
        end
        love.graphics.draw(menuImage, (i - 1) * 32, 0)
    end
    love.graphics.setColor(1, 1, 1) -- Reset color
end
