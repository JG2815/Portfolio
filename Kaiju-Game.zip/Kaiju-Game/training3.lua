local training3 = {}
local projectiles = {}
local winTime = 20  -- Time required to win in seconds
local timeSurvived = 0  -- Time the player has survived
local hasWon = false  -- Flag to check if the player has won
local gameOver = false  -- Flag to check if the player has lost

-- Shield details
local shield = {
    x = 0,
    y = 0,
    width = 10,  -- Default values; these will be scaled by multiplier
    height = 5,
    rotation = 0,  -- Add a rotation property
    downPosition = 0,  -- Define the downward Y position
    upPosition = 0,  -- Define the upward Y position (initial position)
    leftPositionX = 0,
    leftPositionY = 0,
    rightPositionX = 0,
    rightPositionY = 0,
    direction = "up"  -- Add a direction property
}

local laneThickness = 25 -- Default value; to be scaled by multiplier later
local multiplier = 1 -- Add this to adjust scaling factor

-- Define spawnProjectile before calling it inside training3.update
local function spawnProjectile(windowW, windowH, multiplier)
    local proj = {
        width = 5 * multiplier,
        height = 5 * multiplier,
        speed = 90,  -- Adjust speed as needed
        blocked = false
    }

    -- Randomly choose to spawn from one of the four sides
    local spawnSide = math.random(1, 4)  -- Ensure this returns 1, 2, 3, or 4
    if spawnSide == 1 then
        -- Spawn from the top
        proj.x = windowW / 2 - proj.width / 2  -- Center horizontally
        proj.y = -proj.height  -- Spawn just above the screen
        proj.direction = "down"
    elseif spawnSide == 2 then
        -- Spawn from the bottom
        proj.x = windowW / 2 - proj.width / 2  -- Center horizontally
        proj.y = windowH  -- Spawn just below the screen
        proj.direction = "up"
    elseif spawnSide == 3 then
        -- Spawn from the left
        proj.x = -proj.width  -- Spawn just to the left of the screen
        proj.y = windowH / 2 - proj.height / 2  -- Center vertically
        proj.direction = "right"
    else
        -- Spawn from the right
        proj.x = windowW  -- Spawn just to the right of the screen
        proj.y = windowH / 2 - proj.height / 2  -- Center vertically
        proj.direction = "left"
    end

    table.insert(projectiles, proj)
end

-- Function to reset the game
function training3.reset(multiplier, windowW, windowH)
    projectiles = {}
    timeSurvived = 0
    hasWon = false
    gameOver = false  -- Reset gameOver state

    -- Reset shield's properties
    shield.x = windowW / 2 - (shield.width / 2)  -- Center horizontally
    shield.upPosition = windowH / 2 - (shield.height / 2) - 20  -- Default/initial position (up)
    shield.downPosition = shield.upPosition + 30 -- Define the downward position (shifted lower)

    -- Set default left and right positions (these will be corrected later based on state)
    shield.leftPositionX = shield.x - 20
    shield.rightPositionX = shield.x + 20

    -- Reset shield to its initial position and rotation
    shield.y = shield.upPosition
    shield.rotation = 0  -- Reset rotation
    shield.direction = "up"  -- Reset the movement direction
end

-- Load function
function training3.load(multiplier, windowW, windowH)
    if not multiplier then
        error("Error: multiplier not passed to training3.load()")
    end

    windowW = windowW or 160
    windowH = windowH or 144

    -- Scale shield and other elements
    shield.width = 25 * multiplier
    shield.height = 3 * multiplier
    laneThickness = 5 * multiplier

    -- Call reset to initialize the game
    training3.reset(multiplier, windowW, windowH)
end

-- Update function
function training3.update(dt, windowW, windowH)
    if gameOver then return end

    windowW = windowW or 160
    windowH = windowH or 144

    -- Shield movement logic
    if love.keyboard.isDown("down") then
        shield.y = shield.downPosition  -- Move to the defined lower position
        shield.direction = "down"
    elseif love.keyboard.isDown("up") then
        shield.y = shield.upPosition  -- Move to the defined upward (initial) position
        shield.direction = "up"
    end

    local middleYPosition = (shield.upPosition + shield.downPosition) / 2
    local middleXPosition = windowW / 2  -- Middle of the screen in the X direction

    if love.keyboard.isDown("left") then
        shield.rotation = -math.pi / 2  -- Rotate left
        shield.x = shield.leftPositionX -- Move to the left position
        shield.y = middleYPosition  -- Set Y to middle between up and down
        shield.direction = "left"
    elseif love.keyboard.isDown("right") then
        shield.rotation = math.pi / 2  -- Rotate right
        shield.x = shield.rightPositionX -- Move to the right position
        shield.y = middleYPosition  -- Set Y to middle between up and down
        shield.direction = "right"
    elseif love.keyboard.isDown("up") or love.keyboard.isDown("down") then
        shield.rotation = 0  -- Face forward
        shield.x = windowW / 2 - (shield.width / 2)  -- Reset to center horizontally
    end

    -- Spawn projectiles
    if math.random() < 0.008 then
        spawnProjectile(windowW, windowH, multiplier)
    end

    -- Update projectiles and check for collisions
    for i = #projectiles, 1, -1 do
        local proj = projectiles[i]

        -- Move the projectile based on its direction
        if proj.direction == "up" then
            proj.y = proj.y - proj.speed * dt  -- Move upwards
        elseif proj.direction == "down" then
            proj.y = proj.y + proj.speed * dt  -- Move downwards
        elseif proj.direction == "left" then
            proj.x = proj.x - proj.speed * dt  -- Move left
        elseif proj.direction == "right" then
            proj.x = proj.x + proj.speed * dt  -- Move right
        end

        -- Check if the projectile has reached the middle of the screen (losing condition)
        if (proj.direction == "down" and proj.y >= middleYPosition) or 
           (proj.direction == "up" and proj.y <= middleYPosition) or
           (proj.direction == "left" and proj.x <= middleXPosition) or
           (proj.direction == "right" and proj.x >= middleXPosition) then
            -- Player loses when the projectile reaches the middle
            gameOver = true
            changeState("menu")
            training3.reset(multiplier, windowW, windowH)
            return
        end

        -- Check for collisions with the shield
        if checkCollision(shield, proj) then
            -- Block the projectile only if the shield's direction matches the projectile's direction
            if (shield.direction == "up" and proj.direction == "down") or
               (shield.direction == "down" and proj.direction == "up") or
               (shield.direction == "left" and proj.direction == "right") or
               (shield.direction == "right" and proj.direction == "left") then
                -- Block the projectile, do not trigger game over
                proj.blocked = true
            else
                -- If the shield is in the wrong direction, player loses
                gameOver = true
                training3.reset(multiplier, windowW, windowH)
                return
            end
        end
    end

    -- Remove blocked projectiles
    for i = #projectiles, 1, -1 do
        if projectiles[i].blocked then
            table.remove(projectiles, i)
        end
    end

    -- Win condition
    timeSurvived = timeSurvived + dt
    if timeSurvived >= winTime then
        local expGained = 60
        Exp = Exp + expGained
        hasWon = true
        changeState("menu")
        training3.reset(multiplier, windowW, windowH)
    end
end

-- Draw function
function training3.draw(windowW, windowH)
    love.graphics.setColor(1, 1, 1)

    love.graphics.push()

    -- Move to the shield's position and apply rotation
    love.graphics.translate(shield.x + shield.width / 2, shield.y + shield.height / 2)
    love.graphics.rotate(shield.rotation)

    -- Draw the shield centered around its origin
    love.graphics.rectangle("fill", -shield.width / 2, -shield.height / 2, shield.width, shield.height)

    love.graphics.pop()

    -- Draw projectiles
    for _, proj in ipairs(projectiles) do
        love.graphics.rectangle("fill", proj.x, proj.y, proj.width, proj.height)
    end

end

-- Collision function
function checkCollision(shield, proj)
    return proj.x < shield.x + shield.width and
           shield.x < proj.x + proj.width and
           proj.y < shield.y + shield.height and
           shield.y < proj.y + proj.height
end

return training3
