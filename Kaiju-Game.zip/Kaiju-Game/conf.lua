function love.conf(t)
    t.identity = "save"
    t.window.title = "Kaiju Game"
    t.window.icon = "icon.png"
    t.window.width = 160
    t.window.height = 144
    t.window.resizable = false

    t.modules.touch = false
    t.modules.physics = false
    t.modules.joystick = false
    t.audio.mic = false
    t.accelerometerjoystick = true
    t.modules.msaa = 0
end