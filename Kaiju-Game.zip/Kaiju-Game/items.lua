local items = {}

items.list = {
    meat = { 
        name = "Meat", 
        effect = "boostHealth", 
        amount = 20,
        description = "Health Boost",
        duration = 0  -- 0 for instant effect
    },
    vitaminA = { 
        name = "Vitamin A", 
        effect = "boostAttack", 
        amount = 5,
        description = "Attack Boost",
        duration = 3  -- lasts 3 turns
    },
    vitaminD = { 
        name = "Vitamin D", 
        effect = "boostDefense", 
        amount = 5,
        description = "Defense Boost",
        duration = 3  -- lasts 3 turns
    }
}

-- Add inventory system to track items
items.inventory = {}

function items.addToInventory(itemId)
    if not items.inventory[itemId] then
        items.inventory[itemId] = 0
    end
    items.inventory[itemId] = items.inventory[itemId] + 1
end

function items.removeFromInventory(itemId)
    if items.inventory[itemId] and items.inventory[itemId] > 0 then
        items.inventory[itemId] = items.inventory[itemId] - 1
        if items.inventory[itemId] <= 0 then
            items.inventory[itemId] = nil
        end
        return true
    end
    return false
end

function items.getRandomItem()
    local itemNames = { "meat", "vitaminA", "vitaminD" }
    local randomIndex = math.random(#itemNames)
    local itemId = itemNames[randomIndex]
    items.addToInventory(itemId)
    return items.list[itemId]
end

return items