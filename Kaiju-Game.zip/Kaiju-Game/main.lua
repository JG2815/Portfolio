love.graphics.setDefaultFilter("nearest", "nearest", 0)
font = love.graphics.newFont("Fonts/monogram.ttf", 16)
love.graphics.setFont(font)
se1 = love.audio.newSource("Audio/Menu SFX/Menu_Cancel.wav", "static")
se2 = love.audio.newSource("Audio/Menu SFX/Menu_Change.wav", "static")
se3 = love.audio.newSource("Audio/Menu SFX/Menu_Confirm.wav", "static")

--volume for each sound effect (0 is mute and 1 is full volume)
se1:setVolume(0.7)
se2:setVolume(0.7)
se3:setVolume(0.7)
require "menu"
local creature = require "creature"
local training1 = require "training1"
local training2 = require "training2"
local training3 = require "training3"
local quest1 = require "quest1"
local quest2 = require "quest2"
local quest3 = require "quest3"
local quest = require "quest"
local items = require "items" -- Load items from items.lua

Level = 20
Exp = 0 

miniGames = {
    {name = "Training 1", state = "training1Screen"},
    {name = "Training 2", state = "training2Screen"},
    {name = "Training 3", state = "training3Screen"}
}

selectedOption = 1

quests = {
    {name = "Quest 1", state = "quest1"},
    {name = "Quest 2", state = "quest2"},
    {name = "Quest 3", state = "quest3"}
}

local windowW, windowH = love.window.getMode()
multiplier = 2
love.window.setMode(windowW * multiplier, windowH * multiplier)

local currentState = "menu" -- Initial state is the menu
local previousState = nil -- Track previous state for returning from food screen
local hoveredItemIndex = nil  -- Track which item is hovered over
local canUseItems = false  -- Add at top of file with other state variables
local sourceState = nil

function drawDataScreen()
    love.graphics.print("Slime \n Stage \n Type \n Archetype \n Description of monster", multiplier, multiplier)
    -- Add more drawing code for the data screen
end

function drawFoodScreen()
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Items:", multiplier, multiplier)

    if next(items.inventory) == nil then
        love.graphics.print("No items available", 10, 50)
        return
    end

    

    local mouseX, mouseY = love.mouse.getPosition()
    mouseX = mouseX / multiplier
    mouseY = mouseY / multiplier

    local ySpacing = 20
    local yPosition = 20
    local xPosition = 10

    for itemId, count in pairs(items.inventory) do
        local itemDetails = items.list[itemId]
        if itemDetails then
            -- Handle hover effects
            if mouseX >= xPosition and mouseX <= xPosition + font:getWidth(itemDetails.name) and 
               mouseY >= yPosition and mouseY <= yPosition + font:getHeight() then
                -- Show hover highlight
                love.graphics.setColor(1, 0, 0)
                love.graphics.print(string.format("%s x%d", itemDetails.name, count), xPosition, yPosition)
                
                -- Show item description
                love.graphics.setColor(1, 1, 1)
                love.graphics.print(itemDetails.description, 10, 120)

                -- Handle item usage if allowed
                if canUseItems and love.mouse.isDown(1) then
                    if quest1.applyItemEffect(itemId) then
                        se3:play()
                        changeState(previousState)
                    end
                end
            else
                -- Normal display
                love.graphics.setColor(1, 1, 1)
                love.graphics.print(string.format("%s x%d", itemDetails.name, count), xPosition, yPosition)
            end
            
            yPosition = yPosition + ySpacing
        end
    end
end

function drawTrainScreen()
    love.graphics.setColor(1, 1, 1) -- Set text color to white
    love.graphics.print("Training:", multiplier, multiplier)
    
    local mouseX, mouseY = love.mouse.getPosition()
    mouseX = mouseX / multiplier
    mouseY = mouseY / multiplier
    
    for i, game in ipairs(miniGames) do
        local yPosition = (i + 1) * 20 -- Adjust the spacing as needed
        local textX = 10
        local textY = yPosition

        -- Check if the mouse is hovering over the text
        if mouseX >= textX and mouseX <= textX + font:getWidth(game.name) and mouseY >= textY and mouseY <= textY + font:getHeight() then
            love.graphics.setColor(1, 0, 0) -- Set text color to red when hovering
        else
            love.graphics.setColor(1, 1, 1) -- Set text color to white
        end

        -- Lock Training 2 if the player is below level 10
        if game.state == "training2Screen" and Level < 10 then
            love.graphics.print("Level 10", textX + font:getWidth(game.name) + 10, textY)
        end
        
        -- Lock Training 3 if the player is below level 20
        if game.state == "training3Screen" and Level < 20 then
            love.graphics.print("Level 20", textX + font:getWidth(game.name) + 10, textY)
        end

        -- Draw the training option as text
        love.graphics.print(game.name, textX, textY)

        -- Store text positions and sizes in the miniGames table
        game.x = textX
        game.y = textY
        game.width = font:getWidth(game.name)
        game.height = font:getHeight()
    end
end

function drawQuestScreen()
    love.graphics.print("Quest", multiplier, multiplier)

    local mouseX, mouseY = love.mouse.getPosition()
    mouseX = mouseX / multiplier
    mouseY = mouseY / multiplier

    for i, quest in ipairs(quests) do
        local yPosition = (i + 1) * 20 -- Adjust spacing as needed
        local textX = 10
        local textY = yPosition

        -- Highlight text if mouse is hovering
        if mouseX >= textX and mouseX <= textX + font:getWidth(quest.name) and mouseY >= textY and mouseY <= textY + font:getHeight() then
            love.graphics.setColor(1, 0, 0) -- Red for hover
        else
            love.graphics.setColor(1, 1, 1) -- White otherwise
        end

        love.graphics.print(quest.name, textX, textY)

        -- Store text positions and sizes
        quest.x = textX
        quest.y = textY
        quest.width = font:getWidth(quest.name)
        quest.height = font:getHeight()
    end
end

function love.load()
    print("Correct Window Width:", windowW, "Correct Window Height:", windowH) -- Debugging
    local questData = quest.loadQuests("questinfo.txt")

    for questNum, stages in pairs(questData) do
        print(string.format("\nQuest %d:", questNum))
        for stageNum, kaiju in pairs(stages) do
            print(string.format("  Stage %d: Level %d, HP %d", stageNum, kaiju.lvl, kaiju.hp))
        end
    end

    print("Loaded quest data:", questData)
    menuResources()
    creature.init(multiplier, windowW, windowH)
    creature.load()
    training1.load(multiplier, windowW, windowH)
    training2.load(multiplier, windowW, windowH)
    training3.load(multiplier, windowW, windowH)
    quest1.load(multiplier, windowW, windowH, questData[1])
    quest2.load(multiplier, windowW, windowH, questData[2])
    quest3.load(multiplier, windowW, windowH, questData[3])
end

function checkLevelUp()
    local nextLevelExp = 20 + (Level - 1) * 10 -- Example next level experience requirement, you can dynamically adjust this as needed

    if Exp >= nextLevelExp then
        Level = Level + 1 -- Increase level
        Exp = Exp - nextLevelExp -- Subtract the required EXP from current EXP

        -- Increase a random stat
        local statToIncrease = math.random(1, 5)
        local increaseAmount = math.random(3, 7)

        if statToIncrease == 1 then
            creature.kaijuStats.Health = creature.kaijuStats.Health + increaseAmount
            print("Health increased by " .. increaseAmount)
        elseif statToIncrease == 2 then
            creature.kaijuStats.Attack = creature.kaijuStats.Attack + increaseAmount
            print("Attack increased by " .. increaseAmount)
        elseif statToIncrease == 3 then
            creature.kaijuStats.Defense = creature.kaijuStats.Defense + increaseAmount
            print("Defense increased by " .. increaseAmount)
        elseif statToIncrease == 4 then
            creature.kaijuStats.Radiant = creature.kaijuStats.Radiant + increaseAmount
            print("Radiant increased by " .. increaseAmount)
        elseif statToIncrease == 5 then
            creature.kaijuStats.Speed = creature.kaijuStats.Speed + increaseAmount
            print("Speed increased by " .. increaseAmount)
        end
    end
end

function drawExpBar(x, y, width, height)
    -- Calculate next level experience requirement based on current Level
    local nextLevelExp = 20 + (Level - 1) * 10 -- Dynamic next level EXP calculation
    local fillRatio = Exp / nextLevelExp -- Fill ratio based on current EXP and required EXP

    -- Draw the bar background
    love.graphics.setColor(0.2, 0.2, 0.2) -- Dark gray background
    love.graphics.rectangle("fill", x, y, width, height)

    -- Draw the filled portion based on EXP
    love.graphics.setColor(0, 1, 0) -- Green color for EXP bar
    love.graphics.rectangle("fill", x, y, width * fillRatio, height)
end

function love.update(dt)
    if currentState == "menu" then
        menuControls()
        creature.update(dt)
        checkLevelUp()
    elseif currentState == "training1Screen" then
        training1.update(dt)
    elseif currentState == "training2Screen" then
        training2.update(dt)
    elseif currentState == "training3Screen" then
        training3.update(dt)
    elseif currentState == "quest1" then
        quest1.update(dt)
    elseif currentState == "quest2" then
        quest2.update(dt)
    elseif currentState == "quest3" then
        quest3.update(dt)
    elseif currentState == "foodScreen" then
        local mouseX, mouseY = love.mouse.getPosition()
        hoveredItemIndex = nil  -- Reset hover index

        for i, item in ipairs(playerItems) do
            if mouseY >= 30 + (i * 20) and mouseY <= 50 + (i * 20) then
                hoveredItemIndex = i  -- Set hovered item index
                break
            end
        end
    end
end

function love.draw()
    love.graphics.push()
    love.graphics.scale(multiplier, multiplier) -- Apply scaling

    love.graphics.setColor(1, 1, 1) -- Reset color to white

    love.graphics.clear(0, 0, 0) -- Set background color to black

    if currentState == "menu" then
        menuDraw()
        creature.draw()
        creature.drawKaijuStats() 

        local boxX = 132 -- X coordinate of the top right box
        local boxY = 1 -- Y coordinate of the top right box

        -- Add level in the yellow part
        love.graphics.setColor(0, 0, 0) -- Black color for text
        love.graphics.print("LV "..Level, boxX - 2, boxY)
    
        drawExpBar(boxX, boxY + 15, 25, 5)
    elseif currentState == "dataScreen" then
        drawDataScreen()
    elseif currentState == "foodScreen" then
        drawFoodScreen()
    elseif currentState == "trainScreen" then
        drawTrainScreen()
    elseif currentState == "training1Screen" then
        training1.draw()
    elseif currentState == "training2Screen" then
        training2.draw(love.graphics.getWidth(), love.graphics.getHeight())
    elseif currentState == "training3Screen" then
        training3.draw()
    elseif currentState == "questScreen" then
        drawQuestScreen()
    elseif currentState == "quest1" then
        quest1.draw()
    elseif currentState == "quest2" then
        quest2.draw()
    elseif currentState == "quest3" then
        quest3.draw()        
    end

    love.graphics.pop()
end

function love.mousepressed(x, y, button, istouch, presses)
    local mouseX, mouseY = x / multiplier, y / multiplier

    if currentState == "trainScreen" then
        if button == 1 then -- Left mouse button
            for _, game in ipairs(miniGames) do
                if mouseX >= game.x and mouseX <= game.x + game.width and mouseY >= game.y and mouseY <= game.y + game.height then
                    -- Check if the player is trying to access "Training 2" and if the level requirement is met
                    if game.state == "training2Screen" and Level < 10 then
                        love.audio.play(se1) -- Play cancel sound for Training 2
                    elseif game.state == "training3Screen" and Level < 20 then
                        love.audio.play(se1) -- Play cancel sound for Training 3
                    else
                        love.audio.play(se3) -- Play sound effect for confirming selection
                        changeState(game.state)
                    end
                    return
                end
            end
        elseif button == 2 then -- Right mouse button
            love.audio.stop(se1)
            love.audio.play(se1) -- Play sound effect for back action
            changeState("menu")
        end
    elseif currentState == "questScreen" then
        if button == 1 then -- Left mouse button
            for _, quest in ipairs(quests) do
                if mouseX >= quest.x and mouseX <= quest.x + quest.width and mouseY >= quest.y and mouseY <= quest.y + quest.height then
                    love.audio.play(se3) -- Play sound effect for confirming selection
                    changeState(quest.state) -- Transition to the selected stage
                    return
                end
            end
        elseif button == 2 then -- Right mouse button
            love.audio.play(se1) -- Play sound effect for back action
            changeState("menu")
        end
    elseif currentState == "quest1" then
        -- Call the quest1.mousepressed function here
        quest1.mousepressed(mouseX, mouseY, button, istouch, presses)
    elseif currentState == "quest2" then
        -- Call the quest2.mousepressed function here
        quest2.mousepressed(mouseX, mouseY, button, istouch, presses)
    elseif currentState == "quest3" then
        -- Call the quest3.mousepressed function here
        quest3.mousepressed(mouseX, mouseY, button, istouch, presses)
    elseif currentState == "foodScreen" then
        if button == 1 then  -- Left click
            if canUseItems then  -- Only process clicks if items can be used
                local ySpacing = 20
                local yPosition = 20
                local xPosition = 10
                
                for itemId, count in pairs(items.inventory) do
                    local itemDetails = items.list[itemId]
                    if itemDetails then
                        if mouseX >= xPosition and 
                           mouseX <= xPosition + font:getWidth(itemDetails.name) and 
                           mouseY >= yPosition and 
                           mouseY <= yPosition + font:getHeight() then
                            -- Use the correct quest's applyItemEffect based on source
                            local success = false
                            if sourceState == "quest1" then
                                success = quest1.applyItemEffect(itemId)
                            elseif sourceState == "quest2" then
                                success = quest2.applyItemEffect(itemId)
                            elseif sourceState == "quest3" then
                                success = quest3.applyItemEffect(itemId)
                            end
                            if success then
                                se3:play()
                                changeState(previousState)
                                return
                            end
                        end
                        yPosition = yPosition + ySpacing
                    end
                end
            end
        elseif button == 2 then  -- Right click
            changeState(previousState or "menu")
            se1:play()
        end
    else
        if button == 2 then -- Right mouse button for non-train screens
            changeState("menu")
            love.audio.stop(se1)
            love.audio.play(se1)
        end
    end
end

function love.keypressed(key)
    if currentState == "training1Screen" then
        training1.keypressed(key)
    end
end

function changeState(newState)
    if currentState == "training2" then
        training2.unload()
    end

    -- Clear boosts when leaving quest screens
    if (currentState == "quest1" or currentState == "quest2" or currentState == "quest3") 
       and newState == "menu" then
        -- Reset any active boosts
        if activeBoost then
            if activeBoost.effect == "boostAttack" then
                creature.kaijuStats.Attack = creature.kaijuStats.Attack - activeBoost.amount
            elseif activeBoost.effect == "boostDefense" then
                creature.kaijuStats.Defense = creature.kaijuStats.Defense - activeBoost.amount
            end
            activeBoost = nil
            activeBoostTurns = 0
        end
    end

    -- Store source state when entering food screen
    if newState == "foodScreen" then
        sourceState = currentState
        -- Enable item usage for all quest screens
        canUseItems = sourceState and (
            sourceState == "quest1" or 
            sourceState == "quest2" or 
            sourceState == "quest3"
        )
    end

    previousState = currentState
    currentState = newState
end
