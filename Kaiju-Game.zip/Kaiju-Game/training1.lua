local training1 = {}
local cursorX = 0
local cursorSpeed = 200 -- Speed of the cursor
local barWidth = 200
local barHeight = 20 
local rightZoneStart = 50 
local rightZoneEnd = 150
local cursorDirection = 1 -- 1 for right, -1 for left

Trainingse1 = love.audio.newSource("Audio/Menu SFX/Training_1_Edge.wav", "static")
Trainingse2 = love.audio.newSource("Audio/Menu SFX/Training_1_Fail.wav", "static")
Trainingse3 = love.audio.newSource("Audio/Menu SFX/Training_1_Success.wav", "static")

function training1.load(multiplier, windowW, windowH)
    print("training1.load called")
end

function training1.update(dt)
    local margin = 5 -- Adjust this value as needed
    cursorX = cursorX + cursorSpeed * cursorDirection * dt
    if cursorX > barWidth - 10 - margin then
        cursorX = barWidth - 10 - margin
        cursorDirection = -cursorDirection
        Trainingse1:stop()
        Trainingse1:play()
    elseif cursorX < margin then
        cursorX = margin
        cursorDirection = -cursorDirection
        Trainingse1:stop()
        Trainingse1:play()
    end
end

function training1.draw()
    local screenWidth, screenHeight = love.graphics.getDimensions()
    local barX = (screenWidth / multiplier - barWidth) / 2
    local barY = (screenHeight / multiplier - barHeight) / 2

    -- Draw the bar
    love.graphics.setColor(1, 1, 0) -- Yellow color
    love.graphics.rectangle("fill", barX, barY, barWidth, barHeight)

    -- Draw the right zone
    love.graphics.setColor(0, 1, 0) -- Green color
    love.graphics.rectangle("fill", barX + rightZoneStart, barY, rightZoneEnd - rightZoneStart, barHeight)

    -- Draw the cursor
    love.graphics.setColor(1, 0, 0) -- Red color
    love.graphics.rectangle("fill", barX + cursorX, barY, 10, barHeight)

    love.graphics.setColor(1, 1, 1) -- White color
    love.graphics.print("Press Space", barX + (barWidth / 2) - 35, barY + barHeight + 30)
end

function training1.keypressed(key)
    if key == "space" then
        if cursorX >= rightZoneStart and cursorX <= rightZoneEnd then
            Exp = Exp + 10 -- Award experience points for success
            Trainingse3:play()
        else
            Trainingse2:play()
        end
        changeState("menu") -- Return to menu after the minigame
    end
end

return training1
